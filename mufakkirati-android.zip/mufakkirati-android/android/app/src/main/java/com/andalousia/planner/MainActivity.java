package com.andalousia.planner;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
