# مفكرتي · My Planner (Android)

## بناء الـ APK بدون Android Studio (GitHub Actions، مجاني)
1. أنشئ حساب GitHub ومستودعا جديدا (Private).
2. ارفع محتوى هذا المجلد كاملا (بما فيه المجلد المخفي .github).
3. تبويب Actions ثم "Build Android APK" ثم Run workflow.
4. بعد 4 إلى 6 دقائق نزّل `mufakkirati-apk` من أسفل صفحة التشغيل، فك الضغط وثبّت app-debug.apk.
   (اسمح بتثبيت التطبيقات من مصدر غير معروف عند أول مرة.)

## أو بـ Android Studio
npm install ثم npx cap sync android ثم npx cap open android ثم Run.

## بعد أول تشغيل على الهاتف
- اقبل إذن الإشعارات.
- الإعدادات ثم "تفعيل التنبيهات الدقيقة" وفعّل Alarms & reminders إن طُلب.
- على Xiaomi وHuawei وSamsung: عطّل توفير البطارية للتطبيق وفعّل Autostart.
